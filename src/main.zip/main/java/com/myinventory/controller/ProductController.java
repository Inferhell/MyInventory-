package com.myinventory.controller;

import com.myinventory.dto.CreateProductRequest;
import com.myinventory.dto.ProductResponse;
import com.myinventory.dto.UpdateProductRequest;
import com.myinventory.service.ProductService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService){
        this.productService = productService;
    }

    
    @PostMapping
public ProductResponse save(
       @Valid @RequestBody CreateProductRequest request){

    return productService.save(request);
}

  @GetMapping
public List<ProductResponse> findAll() {

    return productService.findAll();
}

    @GetMapping("/{id}")
public ResponseEntity<ProductResponse> findById(
        @PathVariable Long id) {

    ProductResponse product =
            productService.findById(id);

    return ResponseEntity.ok(product);
}
   @PutMapping("/{id}")
public ProductResponse update(
        @PathVariable Long id,
        @Valid @RequestBody UpdateProductRequest request) {

    return productService.update(id, request);
}


    @PatchMapping("/{id}/disable")
    public void disable(@PathVariable Long id) {

    productService.disable(id);
}

} 
