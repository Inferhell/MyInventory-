package com.myinventory.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CreateSupplierRequest {

    @NotBlank(message = "El nombre es obligatorio")
private String name;

@NotBlank(message = "El teléfono es obligatorio")
private String phone;

@Email(message = "Correo inválido")
@NotBlank(message = "El correo es obligatorio")
private String email;

@NotBlank(message = "La dirección es obligatoria")
private String address;

}