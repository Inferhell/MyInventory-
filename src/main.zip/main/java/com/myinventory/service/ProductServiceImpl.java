package com.myinventory.service;

import com.myinventory.model.Category;
import com.myinventory.repository.CategoryRepository;
import com.myinventory.dto.CreateProductRequest;
import com.myinventory.dto.ProductResponse;
import com.myinventory.model.Product;
import com.myinventory.repository.ProductRepository;
import org.springframework.stereotype.Service;
import com.myinventory.dto.UpdateProductRequest;
import com.myinventory.exception.ResourceNotFoundException;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {
private final ProductRepository productRepository;
private final CategoryRepository categoryRepository;    

        public ProductServiceImpl(
        ProductRepository productRepository,
        CategoryRepository categoryRepository) {

        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
}
    
    @Override
public ProductResponse save(CreateProductRequest request) {
        Category category = categoryRepository
        .findByIdAndActiveTrue(
                request.getCategoryId())
        .orElseThrow(() ->
                new ResourceNotFoundException(
                        "Categoría no encontrada"));    

    Product product = Product.builder()
        .name(request.getName())
        .description(request.getDescription())
        .price(request.getPrice())
        .stock(request.getStock())
        .category(category)
        .active(true)
        .build();

    Product saved = productRepository.save(product);

    return ProductResponse.builder()
        .id(saved.getId())
        .name(saved.getName())
        .description(saved.getDescription())
        .price(saved.getPrice())
        .stock(saved.getStock())
        .active(saved.isActive())
        .categoryId(saved.getCategory().getId())
        .categoryName(saved.getCategory().getName())
        .build();
}

private ProductResponse toResponse(Product product) {

    return ProductResponse.builder()
            .id(product.getId())
            .name(product.getName())
            .description(product.getDescription())
            .price(product.getPrice())
            .stock(product.getStock())
            .active(product.isActive())

            .categoryId(
                    product.getCategory() != null
                            ? product.getCategory().getId()
                            : null
            )

            .categoryName(
                    product.getCategory() != null
                            ? product.getCategory().getName()
                            : null
            )

            .build();
}

    @Override
public List<ProductResponse> findAll() {

    return productRepository
            .findByActiveTrue()
            .stream()
            .map(this::toResponse)
            .toList();
}


   @Override
public ProductResponse findById(Long id) {

    Product product = productRepository
            .findByIdAndActiveTrue(id)
            .orElseThrow(() ->
                    new ResourceNotFoundException(
                            "Producto no encontrado"));

    return toResponse(product);
}

private Product getProductEntity(Long id) {

    return productRepository
            .findByIdAndActiveTrue(id)
            .orElseThrow(() ->
                    new ResourceNotFoundException(
                            "Producto no encontrado"));
}

    @Override
    public ProductResponse update(
        Long id,
        UpdateProductRequest request) {

        Product existing = getProductEntity(id);
        Category category = categoryRepository
        .findByIdAndActiveTrue(
                request.getCategoryId())
        .orElseThrow(() ->
                new ResourceNotFoundException(
                        "Categoría no encontrada"));

      

        existing.setName(request.getName());
        existing.setDescription(request.getDescription());
        existing.setPrice(request.getPrice());
        existing.setStock(request.getStock());
        existing.setCategory(category);

        Product updated = productRepository.save(existing);
        return ProductResponse.builder()
        .id(updated.getId())
        .name(updated.getName())
        .description(updated.getDescription())
        .price(updated.getPrice())
        .stock(updated.getStock())
        .active(updated.isActive())
        .categoryId(updated.getCategory().getId())
        .categoryName(updated.getCategory().getName())
        .build();
    }

        
        @Override
        public void disable(Long id) {

        Product product = getProductEntity(id);

        product.setActive(false);

        productRepository.save(product);
    }

    }


