package com.myinventory.service;

import com.myinventory.dto.CreateProductRequest;
import com.myinventory.dto.ProductResponse;
import com.myinventory.dto.UpdateProductRequest;

import java.util.List;

public interface ProductService {

    ProductResponse save(CreateProductRequest request);

   List<ProductResponse> findAll();

    ProductResponse findById(Long id);

    ProductResponse update(
            Long id,
            UpdateProductRequest request);

    void disable(Long id);
}